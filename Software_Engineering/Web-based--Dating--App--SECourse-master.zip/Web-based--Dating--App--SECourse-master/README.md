# Web-based--Dating--App--SECourse
This repository serves the purpose of storing files which are included in the project in Software Engineering course. This project was done by team 7 which has three members(Binh Bui - e1300518; Nguyen Cong Danh - e1400467; Thanh Vuong - e1400489)
